import sampleClasses.Cat;

import java.util.Scanner;
public class Main{


     public static void main(String []args) {
          /* Object creation */
          Cat myCat = new Cat( "Ananya" );

          /* Call class method to set puppy's age */
          myCat.setCatAge( 6 );

          /* Call another class method to get puppy's age */
          int age = myCat.getCatAge( );

          /* You can access instance variable as follows as well */
          System.out.println("Variable Value :" + age);
     }
}
