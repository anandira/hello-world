package sampleClasses;

public class Cat {

    int catAge;

    public Cat(String name ) {
        //This construction has one parameter, name.
        System.out.println("Name Chosen Is:" + name);
    }
public void setCatAge (int age) {
        catAge = age;
}

    public int getCatAge() {
        System.out.println("Cat's age is :" + catAge);
        return catAge;
    }
}
